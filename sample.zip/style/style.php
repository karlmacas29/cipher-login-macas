<style>
        /* Light Mode */
        body{
        margin: 0;
        transition: background-color 0.3s;
        }

        
        ::-webkit-scrollbar {
        width: 7px;
        background-color: white;
        }

        

        ::-webkit-scrollbar-thumb {
        background-color: skyblue;
        }
        /* Custom CSS for the sidebar */



    </style>